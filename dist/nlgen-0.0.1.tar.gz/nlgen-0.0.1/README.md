# nlgen
MJML newsletter generator in Python

# Installation

pip install git+ht<span>tps://</span>github.com/galmeriol/nlgen#egg=nlgen
